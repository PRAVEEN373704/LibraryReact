import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';  

function Home() {
  const [books, setBooks] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
//   const navigate = useNavigate();  

  useEffect(() => {
    axios.get('https://localhost:7236/Books/api/Booklist')
      .then(response => {
        if (response.data && Array.isArray(response.data)) {
          setBooks(response.data);
        } else {
          setError('Invalid response from API');
        }
      })
      .catch(error => {
        setError('Failed to fetch books');
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  const handleAddBook = () => {
    // Add your logic to add a new book here
    // navigate('./BookEntry');
    console.log('Add book button clicked');
  };

  const handleAddCategory = () => {
    // Add your logic to add a new category here
    console.log('Add category button clicked');
  };

  const handleAddAuthor = () => {
    // Add your logic to add a new author here
    console.log('Add author button clicked');
  };

  if (loading) {
    return (
      <div className="loading-container">
        <h1>Loading...</h1>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <h1>Error: {error}</h1>
      </div>
    );
  }

  return (
    <div className="book-list-container">
      <div className="button-container">
        <button className="add-button" onClick={handleAddBook}>Add Book</button>
        <button className="add-button" onClick={handleAddCategory}>Add Category</button>
        <button className="add-button" onClick={handleAddAuthor}>Add Author</button>
      </div>
      <h1 className="title">Book List</h1>
      <ul className="book-list">
        {books.map(book => (
          <li key={book.id} className="book-item">
            <div className="book-image">
              <img src={"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROsviQWs_X4CNleW1RprSIuiXXNK1SAel1dAOAuoPnwQoS9r9LR4laXg9gBqn94GhOE8I&usqp=CAU"} alt={book.title} />
            </div>
            <div className="book-info">
              <h2 className="book-title">{book.title}</h2>
              <p className="book-description">{book.description}</p>
              <p className="book-publication-year">Publication Year: {book.publicationYear}</p>
            </div>
          </li>
        ))}
      </ul>
      <style>
        {`
          .loading-container, .error-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-size: 24px;
          }

          .book-list-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          }

          .button-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
          }

          .add-button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
          }

          .add-button:hover {
            background-color: #3e8e41;
          }

          .title {
            text-align: center;
            margin-bottom: 20px;
          }

          .book-list {
            list-style: none;
            padding: 0;
            margin: 0;
          }

          .book-item {
            display: flex;
            margin-bottom: 20px;
            padding: 20px;
            border-bottom: 1px solid #ddd;
          }

          .book-image {
            width: 100px;
            height: 150px;
            margin-right: 20px;
          }

          .book-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
          }

          .book-info {
            flex-grow: 1;
          }

                    .book-title {
            font-size: 18px;
            margin-bottom: 10px;
          }

          .book-description {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
          }

          .book-publication-year {
            font-size: 14px;
            color: #666;
          }
        `}
      </style>
    </div>
  );
}

export default Home;

